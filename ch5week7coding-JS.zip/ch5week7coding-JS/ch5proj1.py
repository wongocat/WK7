def read_file(filename):
    try:
        with open(filename) as file:
            lines = file.readlines()
            return lines
    except FileNotFoundError:
        print("Error: File not found.")
        return []

def main():
    filename = input("Enter filename: ")
    lines = read_file(filename)
    
    while True:
        num_lines = len(lines)
        print("Number of lines:", num_lines)
        line_num = int(input("Enter line number (0 to quit): "))
        
        if line_num == 0:
            break
        elif line_num < 1 or line_num > num_lines:
            print("Error: Invalid line number.")
        else:
            print(lines[line_num - 1])
    
if __name__ == '__main__':
    main()
